//
// Written by Yousef Abualeinan
// As a button is pressed, LED's color will cycle
// following a specific order
//

#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"

#define LED_RED GPIO_PIN_1
#define LED_BLUE GPIO_PIN_2
#define LED_GREEN GPIO_PIN_3
#define LED_ALL (LED_RED | LED_BLUE | LED_GREEN)
#define SW1 GPIO_PIN_4

#define COLOR_BLACK 0x0
#define COLOR_WHITE LED_ALL
#define COLOR_RED LED_RED
#define COLOR_BLUE LED_BLUE
#define COLOR_GREEN LED_GREEN
#define COLOR_PURPLE (LED_RED | LED_BLUE)
#define COLOR_CYAN (LED_BLUE | LED_GREEN)
#define COLOR_YELLOW (LED_RED | LED_GREEN)

#ifdef DEBUG
void __error__(char *pcFilename, uint32_t ui32Line) {
    while(1);
}
#endif

void delay_cycles(uint32_t cycles) {
  // initialize SysTick timer
  SysTick->LOAD = cycles - 1;
  SysTick->VAL = 0;
  SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_ENABLE_Msk;

  // wait for delay to elapse
  while ((SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) == 0);

  // disable SysTick timer
  SysTick->CTRL = 0;
}

int main(void) {

    volatile uint32_t SW1Read;
    volatile uint32_t currentColor = COLOR_BLACK;

    // Enable the GPIO port that is used for the on-board LED.
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    // Check if the peripheral access is enabled.
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF))
    {
    }

    // Set the direction as output, and enable the GPIO pin for digital function.

    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, LED_RED);
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, LED_BLUE);
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, LED_GREEN);

    // Set the switch as an input
    GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, SW1);

    // Set up the pull-up Resistor
    GPIOPadConfigSet(GPIO_PORTF_BASE, SW1, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);


    // Loop forever.
    while(1)
    {
        SW1Read = GPIOPinRead(GPIO_PORTF_BASE, SW1);


        if (!SW1Read) {
            SysCtlDelay(200000); // debouncing SysTick delay
            // reread switch
            SW1Read = GPIOPinRead(GPIO_PORTF_BASE, SW1);
            // ensure no repeat signal
            if (!SW1Read) {
                // color sequence switching
                    // black to red
                if (currentColor == COLOR_BLACK) {
                    GPIOPinWrite(GPIO_PORTF_BASE, LED_ALL, 0x0);
                    currentColor = COLOR_RED;
                    GPIOPinWrite(GPIO_PORTF_BASE, COLOR_RED, COLOR_RED);
                    // red to purple
                } else if (currentColor == COLOR_RED) {
                    GPIOPinWrite(GPIO_PORTF_BASE, LED_ALL, 0x0);
                    currentColor = COLOR_PURPLE;
                    GPIOPinWrite(GPIO_PORTF_BASE, COLOR_PURPLE, COLOR_PURPLE);
                    // purple to green
                } else if (currentColor == COLOR_PURPLE) {
                    GPIOPinWrite(GPIO_PORTF_BASE, LED_ALL, 0x0);
                    currentColor = COLOR_GREEN;
                    GPIOPinWrite(GPIO_PORTF_BASE, COLOR_GREEN, COLOR_GREEN);
                    // green to cyan
                } else if (currentColor == COLOR_GREEN) {
                    GPIOPinWrite(GPIO_PORTF_BASE, LED_ALL, 0x0);
                    currentColor = COLOR_CYAN;
                    GPIOPinWrite(GPIO_PORTF_BASE, COLOR_CYAN, COLOR_CYAN);
                    // cyan to blue
                } else if (currentColor == COLOR_CYAN) {
                    GPIOPinWrite(GPIO_PORTF_BASE, LED_ALL, 0x0);
                    currentColor = COLOR_BLUE;
                    GPIOPinWrite(GPIO_PORTF_BASE, COLOR_BLUE, COLOR_BLUE);
                    // blue to yellow
                } else if (currentColor == COLOR_BLUE) {
                    GPIOPinWrite(GPIO_PORTF_BASE, LED_ALL, 0x0);
                    currentColor = COLOR_YELLOW;
                    GPIOPinWrite(GPIO_PORTF_BASE, COLOR_YELLOW, COLOR_YELLOW);
                    // yellow to white
                } else if (currentColor == COLOR_YELLOW) {
                    GPIOPinWrite(GPIO_PORTF_BASE, LED_ALL, 0x0);
                    currentColor = COLOR_WHITE;
                    GPIOPinWrite(GPIO_PORTF_BASE, COLOR_WHITE, COLOR_WHITE);
                    // white to black
                } else if (currentColor == COLOR_WHITE) {
                    currentColor = COLOR_BLACK;
                    GPIOPinWrite(GPIO_PORTF_BASE, LED_ALL, COLOR_BLACK);
                }

                // do nothing until switch is released
                while(!SW1Read) {
                    // update switch read
                    SW1Read = GPIOPinRead(GPIO_PORTF_BASE, SW1);
                }
            }
        }
    }
}
